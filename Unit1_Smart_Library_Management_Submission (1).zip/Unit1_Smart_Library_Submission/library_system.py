"""
Smart Library Management System
Python Programming – Unit 1: Getting Started with Python

Console-based prototype for adding, displaying, searching, issuing, and
returning library books.
"""

library = []


def find_book(book_id):
    """Return a book record by ID, or None if it is not found."""
    for book in library:
        if book["book_id"].lower() == book_id.strip().lower():
            return book
    return None


def add_book():
    print("\n--- Add a New Book ---")
    book_id = input("Enter Book ID: ").strip()
    if not book_id:
        print("Error: Book ID cannot be empty.")
        return
    if find_book(book_id):
        print(f"Error: A book with ID '{book_id}' already exists.")
        return

    title = input("Enter Book Title: ").strip()
    author = input("Enter Author Name: ").strip()
    if not title or not author:
        print("Error: Title and author cannot be empty.")
        return

    try:
        total_copies = int(input("Enter Total Number of Copies: ").strip())
        if total_copies <= 0:
            print("Error: Number of copies must be a positive integer.")
            return
    except ValueError:
        print("Error: Please enter a valid whole number for copies.")
        return

    library.append({
        "book_id": book_id,
        "title": title,
        "author": author,
        "total_copies": total_copies,
        "available_copies": total_copies
    })
    print(f"Book '{title}' added successfully.")


def display_books():
    print("\n--- Library Book List ---")
    if not library:
        print("No books available in the library.")
        return

    print(f"{'ID':<10}{'Title':<28}{'Author':<24}{'Total':<8}{'Available':<10}")
    print("-" * 80)
    for book in library:
        print(
            f"{book['book_id']:<10}{book['title']:<28}{book['author']:<24}"
            f"{book['total_copies']:<8}{book['available_copies']:<10}"
        )


def search_book():
    print("\n--- Search a Book ---")
    keyword = input("Enter Book ID or Title to search: ").strip().lower()
    if not keyword:
        print("Please enter a search term.")
        return

    matches = [
        book for book in library
        if keyword == book["book_id"].lower()
        or keyword in book["title"].lower()
    ]
    if not matches:
        print("No matching book found.")
        return

    for book in matches:
        print("-" * 40)
        print(f"Book ID: {book['book_id']}")
        print(f"Title: {book['title']}")
        print(f"Author: {book['author']}")
        print(f"Total copies: {book['total_copies']}")
        print(f"Available copies: {book['available_copies']}")


def issue_book():
    print("\n--- Issue a Book ---")
    book_id = input("Enter Book ID to issue: ").strip()
    book = find_book(book_id)
    if not book:
        print("Error: Book ID not found.")
        return

    if book["available_copies"] > 0:
        book["available_copies"] -= 1
        print(
            f"Book '{book['title']}' issued successfully. "
            f"Available copies now: {book['available_copies']}."
        )
    else:
        print(f"Sorry, '{book['title']}' is currently out of stock.")


def return_book():
    print("\n--- Return a Book ---")
    book_id = input("Enter Book ID to return: ").strip()
    book = find_book(book_id)
    if not book:
        print("Error: Book ID not found.")
        return

    if book["available_copies"] < book["total_copies"]:
        book["available_copies"] += 1
        print(
            f"Book '{book['title']}' returned successfully. "
            f"Available copies now: {book['available_copies']}."
        )
    else:
        print("Error: All copies of this book are already in the library.")


def display_menu():
    print("\n===== SMART LIBRARY MANAGEMENT SYSTEM =====")
    print("1. Add a New Book")
    print("2. Display All Books")
    print("3. Search a Book")
    print("4. Issue a Book")
    print("5. Return a Book")
    print("6. Exit")


def main():
    while True:
        display_menu()
        choice = input("Enter your choice (1-6): ").strip()

        if choice == "1":
            add_book()
        elif choice == "2":
            display_books()
        elif choice == "3":
            search_book()
        elif choice == "4":
            issue_book()
        elif choice == "5":
            return_book()
        elif choice == "6":
            print("Thank you for using the Smart Library Management System. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 6.")


if __name__ == "__main__":
    main()
