# Smart Library Management System — Unit 1

A console-based Python mini project for the Unit 1 “Getting Started with Python” assignment.

## Features
- Add a book with a unique Book ID
- Display all stored books
- Search by Book ID or title
- Issue a book when a copy is available
- Return a previously issued book
- Validate duplicate IDs, invalid copy counts, and invalid menu choices

## How to run
1. Install Python 3 if it is not already installed.
2. Open a terminal in this folder.
3. Run `python library_system.py` (on some Windows systems, use `py library_system.py`).

## Data and limitation
This is a beginner console prototype. Records are stored in memory and reset when the program exits.
The attached project implementation document contains the problem statement, requirements, algorithms,
flowchart representations, pseudocode, testing discussion, and GitHub guidance.

## Before submission
Run the program yourself and take screenshots of the menu, adding/searching a book, and issuing/returning a book.
